﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalCheck.Models
{
    public class MovieOperations
    {
        private DataConnect op = new DataConnect();

        public IEnumerable<Movie> MovieFilter()
        {
            var movies = from item in op.Movie select item;

            movies = movies.Where(item => item.Active.Equals("Yes")
                                        && item.DOL <= DateTime.Now);
            return movies;
        }

        public IEnumerable<Movie> FavMovieAccess(int id)
        {
            var fabs = from item in op.Favourite where item.Id == id select item.FavId;

            var movies = from i in op.Movie where fabs.Any(x => x.Equals(i.MovieId)) select i;

            return movies;
        }

        public IEnumerable<Favourite> FavAccess(int id)
        {
            var fab = from item in op.Favourite where item.FavId == id select item;
            return fab;
        }

    }
}
