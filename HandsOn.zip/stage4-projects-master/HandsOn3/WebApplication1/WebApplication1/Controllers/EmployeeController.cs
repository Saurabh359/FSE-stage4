﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Filters;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private List<Employee> Emp = new List<Employee>
        {
            new Employee{Id=1,Name="Saurabh",Age=22},
            new Employee{Id=2,Name="Radhika",Age=22},
            new Employee{Id=3,Name="Priya",Age=22}
        };

        private List<Employee> GetStandardEmployeeList()
        {
            return Emp;
        }

        // GET: api/Employee
        [CustomAuthFilter]
        [HttpGet]
        public IEnumerable<Employee> Get()
        {
            return GetStandardEmployeeList(); 
        }

        // GET: api/Employee/5

        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [HttpGet("{id}", Name = "Get")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult Get(int id)
        {
            var person = Emp.FirstOrDefault((p) => p.Id == id);
            if(person==null)
            {
                return NotFound();
            }
            return Ok(person);
            throw new Exception();
        }

        // POST: api/Employee
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT: api/Employee/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
