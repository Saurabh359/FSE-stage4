﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Filters
{
    
    public class CustomAuthFilter:ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context) 
        {
            if(context.HttpContext.Request.Query.ContainsKey("Authorization"))
            {
                //context.Result = new UnauthorizedResult();
                if(context.HttpContext.Request.Query["Authorization"] != "Bearer")
                {
                    context.Result = new BadRequestObjectResult("Toke Present but Bearer not");
                }
                base.OnActionExecuting(context);
            }
            else
            {
                context.Result = new BadRequestObjectResult("No Auth Token11514");
            }
        }
    }

}
