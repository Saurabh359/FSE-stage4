﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Filters
{
    public class CustomExceptionFilter: IExceptionFilter
    {

        public void OnException(ExceptionContext context)
        {
            Exception exp = context.Exception;
            string msg = exp.Message;
            using (StreamWriter writer = new StreamWriter("C:\\Users\\user\\Desktop\\exception.txt"))
            {
                writer.WriteLine(msg);
            }
            IActionResult ExceptionResult = null;
            context.Result = ExceptionResult;
        }
    }
}
