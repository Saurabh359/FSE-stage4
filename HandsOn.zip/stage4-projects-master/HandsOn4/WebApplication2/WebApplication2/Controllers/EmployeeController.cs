﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication2.Models;
using WebApplication2.Filters;
using Microsoft.AspNetCore.Mvc.Filters;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    public class EmployeeController : Controller
    {
        private static List<Employee> Emp = new List<Employee>();

        // GET: api/<controller>
        [HttpGet]
        public IActionResult Get()
        {
            return new ObjectResult(Emp);
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            return new ObjectResult(Emp.FirstOrDefault(p => p.Id == id));
        }

        // POST api/<controller>
        [HttpPost]
        public void Post([FromBody]Employee employee)
        {
            Emp.Add(employee);
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]Employee employee)
        {
            Emp.FirstOrDefault(p => p.Id == id).Age = employee.Age;
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            var empl =Emp.FirstOrDefault(p => p.Id == id);
            Emp.Remove(empl);
        }
    }
}
